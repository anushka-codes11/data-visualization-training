import numpy as np

# Create a 5x5 matrix with random integers between 1 and 100
matrix = np.random.randint(1, 101, (5, 5))

print("Matrix:\n", matrix)

# Find minimum and maximum values
min_value = matrix.min()
max_value = matrix.max()

print("Minimum value:", min_value)
print("Maximum value:", max_value)

//output:
matrix :
[[80 83  1 32 79]
 [94 77 83 29 23]
 [98  9 78 22 89]
 [14 34 45  1 72]
 [43 32 62 82 35]]
Minimum value: 1
Maximum value: 98