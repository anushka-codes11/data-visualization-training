import numpy as np

# Create a 3x3 matrix
matrix = np.array([[1, 2, 3],
                   [4, 5, 6],
                   [7, 8, 9]])

# Calculate transpose
transpose_matrix = matrix.T

print("Original Matrix:")
print(matrix)

print("\nTranspose of the Matrix:")
print(transpose_matrix)
  
  //output :

 Original Matrix:
[[1 2 3]
 [4 5 6]
 [7 8 9]]

Transpose of the Matrix:
[[1 4 7]
 [2 5 8]
 [3 6 9]]


