import numpy as np

# Create a 4x4 matrix
matrix = np.array([[1, 2, 3, 4],
                   [5, 6, 7, 8],
                   [9, 10, 11, 12],
                   [13, 14, 15, 16]])

# Row-wise sum
row_sum = matrix.sum(axis=1)

# Column-wise sum
col_sum = matrix.sum(axis=0)

print("4x4 Matrix:")
print(matrix)

print("\nRow-wise sum:", row_sum)
print("Column-wise sum:", col_sum)  


// output :

4x4 Matrix:
[[ 1  2  3  4]
 [ 5  6  7  8]
 [ 9 10 11 12]
 [13 14 15 16]]

Row-wise sum: [10 26 42 58]
Column-wise sum: [28 32 36 40]