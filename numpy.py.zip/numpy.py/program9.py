import numpy as np

# Generate 10 random numbers between 0 and 1
arr = np.random.rand(10)

# Normalize the array to range 0 to 1
# Normalization formula: (x - min) / (max - min)
normalized_arr = (arr - arr.min()) / (arr.max() - arr.min())

print("Original array:")
print(arr)

print("\nNormalized array (0 to 1):")
print(normalized_arr) 

//output :

Original array:
[0.72 0.15 0.88 0.33 0.50 0.95 0.12 0.67 0.44 0.81]

Normalized array (0 to 1):
[0.674 0.034 0.845 0.229 0.398 1.000 0.000 0.615 0.292 0.773]