import numpy as np

# Create two 3x3 matrices
matrix1 = np.array([[1, 2, 3],
                    [4, 5, 6],
                    [7, 8, 9]])

matrix2 = np.array([[9, 8, 7],
                    [6, 5, 4],
                    [3, 2, 1]])

# Perform matrix multiplication
result = np.dot(matrix1, matrix2)

# Display matrices and result
print("Matrix 1:")
print(matrix1)

print("\nMatrix 2:")
print(matrix2)

print("\nMatrix Multiplication Result:")
print(result) 

//output :

Matrix 1:
[[1 2 3]
 [4 5 6]
 [7 8 9]]

Matrix 2:
[[9 8 7]
 [6 5 4]
 [3 2 1]]

Matrix Multiplication Result:
[[ 30  24  18]
 [ 84  69  54]
 [138 114  90]]