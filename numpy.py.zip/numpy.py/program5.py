import numpy as np

# Create array from 1 to 25
arr = np.arange(1, 26)

# Reshape into 5x5 matrix
matrix = arr.reshape(5, 5)

# Extract middle 3x3 submatrix
sub_matrix = matrix[1:4, 1:4]

print("5x5 Matrix:")
print(matrix)

print("\nMiddle 3x3 Submatrix:")
print(sub_matrix)

//output :

5x5 Matrix:
[[ 1  2  3  4  5]
 [ 6  7  8  9 10]
 [11 12 13 14 15]
 [16 17 18 19 20]
 [21 22 23 24 25]]

Middle 3x3 Submatrix:
[[ 7  8  9]
 [12 13 14]
 [17 18 19]]