import numpy as np

# Create array from 1 to 10
arr = np.arange(1, 11)

# Reverse the array
reversed_arr = arr[::-1]

print("Original array:", arr)
print("Reversed array:", reversed_arr) 

//output:

Original array: [ 1  2  3  4  5  6  7  8  9 10]
Reversed array: [10  9  8  7  6  5  4  3  2  1]